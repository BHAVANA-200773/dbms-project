import { Minus, Plus, Trash2 } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useStore } from "@/lib/store";
import { money, orderTotals, type Order, type OrderItem } from "@/lib/types";

export function OrderDialog({
  open,
  onOpenChange,
  order,
  defaultTableId,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  order?: Order | null;
  defaultTableId?: string;
}) {
  const { foods, tables, customers, orders, settings, saveOrder, nextId } = useStore();
  const [customerId, setCustomerId] = useState("");
  const [tableId, setTableId] = useState("");
  const [items, setItems] = useState<OrderItem[]>([]);
  const [notes, setNotes] = useState("");
  const [discount, setDiscount] = useState(0);
  const [query, setQuery] = useState("");

  useEffect(() => {
    if (!open) return;
    setCustomerId(order?.customerId ?? customers[0]?.id ?? "");
    setTableId(order?.tableId ?? defaultTableId ?? tables[0]?.id ?? "");
    setItems(order?.items ? order.items.map((i) => ({ ...i })) : []);
    setNotes(order?.notes ?? "");
    setDiscount(order?.discount ?? 0);
    setQuery("");
  }, [open, order, defaultTableId, customers, tables]);

  const available = useMemo(
    () =>
      foods.filter(
        (f) => f.available && f.name.toLowerCase().includes(query.trim().toLowerCase()),
      ),
    [foods, query],
  );

  const draft: Order = {
    id: order?.id ?? "new",
    customerId,
    customerName: customers.find((c) => c.id === customerId)?.name ?? "Walk-in",
    tableId,
    items,
    notes,
    discount,
    status: order?.status ?? "Pending",
    createdAt: order?.createdAt ?? new Date().toISOString(),
    paymentMethod: order?.paymentMethod ?? "Cash",
    paymentStatus: order?.paymentStatus ?? "Pending",
  };
  const totals = orderTotals(draft, settings.taxPercent);

  const add = (id: string) => {
    const f = foods.find((x) => x.id === id);
    if (!f) return;
    setItems((prev) =>
      prev.some((i) => i.itemId === id)
        ? prev.map((i) => (i.itemId === id ? { ...i, quantity: i.quantity + 1 } : i))
        : [...prev, { itemId: f.id, name: f.name, price: f.price, quantity: 1 }],
    );
  };
  const bump = (id: string, delta: number) =>
    setItems((prev) =>
      prev
        .map((i) => (i.itemId === id ? { ...i, quantity: i.quantity + delta } : i))
        .filter((i) => i.quantity > 0),
    );

  const submit = () => {
    if (!customerId) {
      toast.error("Please select a customer");
      return;
    }
    if (!tableId) {
      toast.error("Please select a table");
      return;
    }
    if (items.length === 0) {
      toast.error("Add at least one food item");
      return;
    }
    if (discount < 0 || discount > totals.subtotal) {
      toast.error("Discount must be between 0 and the subtotal");
      return;
    }
    saveOrder({ ...draft, id: order?.id ?? nextId("ORD", orders) });
    toast.success(order ? "Order updated" : "Order created successfully");
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] max-w-4xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{order ? `Edit ${order.id}` : "Create New Order"}</DialogTitle>
          <DialogDescription>
            Pick a table and customer, then add items from the menu.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-5 md:grid-cols-2">
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Table</Label>
                <Select value={tableId} onValueChange={setTableId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select table" />
                  </SelectTrigger>
                  <SelectContent>
                    {tables.map((t) => (
                      <SelectItem key={t.id} value={t.id}>
                        Table {t.number} · {t.capacity} seats ({t.status})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Customer</Label>
                <Select value={customerId} onValueChange={setCustomerId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select customer" />
                  </SelectTrigger>
                  <SelectContent>
                    {customers.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>Add items</Label>
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search menu..."
              />
              <div className="max-h-56 space-y-1 overflow-y-auto rounded-lg border p-2">
                {available.length === 0 && (
                  <p className="p-3 text-center text-sm text-muted-foreground">No items found</p>
                )}
                {available.map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => add(f.id)}
                    className="flex w-full items-center gap-3 rounded-md px-2 py-2 text-left text-sm transition-colors hover:bg-muted"
                  >
                    <span className="text-lg">{f.emoji}</span>
                    <span className="flex-1 truncate">{f.name}</span>
                    <span className="text-muted-foreground">
                      {money(f.price, settings.currency)}
                    </span>
                    <Plus className="h-4 w-4 text-primary" />
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>Special instructions</Label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. less spicy, no onion"
              />
            </div>
          </div>

          <div className="space-y-4">
            <div className="rounded-xl border">
              <p className="border-b px-4 py-2 text-sm font-medium">Order items</p>
              <div className="max-h-64 divide-y overflow-y-auto">
                {items.length === 0 && (
                  <p className="p-6 text-center text-sm text-muted-foreground">
                    No items added yet
                  </p>
                )}
                {items.map((i) => (
                  <div key={i.itemId} className="flex items-center gap-2 px-3 py-2">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{i.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {money(i.price, settings.currency)} each
                      </p>
                    </div>
                    <Button
                      type="button"
                      size="icon"
                      variant="outline"
                      className="h-7 w-7"
                      onClick={() => bump(i.itemId, -1)}
                      aria-label="Decrease quantity"
                    >
                      <Minus className="h-3 w-3" />
                    </Button>
                    <span className="w-6 text-center text-sm">{i.quantity}</span>
                    <Button
                      type="button"
                      size="icon"
                      variant="outline"
                      className="h-7 w-7"
                      onClick={() => bump(i.itemId, 1)}
                      aria-label="Increase quantity"
                    >
                      <Plus className="h-3 w-3" />
                    </Button>
                    <span className="w-16 text-right text-sm font-medium">
                      {money(i.price * i.quantity, settings.currency)}
                    </span>
                    <Button
                      type="button"
                      size="icon"
                      variant="ghost"
                      className="h-7 w-7 text-destructive"
                      onClick={() => setItems((p) => p.filter((x) => x.itemId !== i.itemId))}
                      aria-label="Remove item"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>Discount ({settings.currency})</Label>
              <Input
                type="number"
                min={0}
                value={discount}
                onChange={(e) => setDiscount(Number(e.target.value) || 0)}
              />
            </div>

            <div className="space-y-1 rounded-xl bg-muted/60 p-4 text-sm">
              <Row label="Subtotal" value={money(totals.subtotal, settings.currency)} />
              <Row
                label={`Tax (${settings.taxPercent}%)`}
                value={money(totals.tax, settings.currency)}
              />
              <Row label="Discount" value={`- ${money(totals.discount, settings.currency)}`} />
              <div className="mt-2 flex justify-between border-t pt-2 text-base font-semibold">
                <span>Grand Total</span>
                <span>{money(totals.total, settings.currency)}</span>
              </div>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={submit}>{order ? "Save changes" : "Create order"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between text-muted-foreground">
      <span>{label}</span>
      <span className="font-medium text-foreground">{value}</span>
    </div>
  );
}
