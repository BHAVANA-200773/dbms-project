import { cn } from "@/lib/utils";

const MAP: Record<string, string> = {
  Pending: "bg-warning/15 text-warning-foreground border-warning/40",
  Confirmed: "bg-info/15 text-info border-info/40",
  Preparing: "bg-accent/20 text-accent-foreground border-accent/50",
  Ready: "bg-info/15 text-info border-info/40",
  Served: "bg-secondary text-secondary-foreground border-border",
  Completed: "bg-success/15 text-success border-success/40",
  Cancelled: "bg-destructive/12 text-destructive border-destructive/40",
  Available: "bg-success/15 text-success border-success/40",
  Occupied: "bg-primary/12 text-primary border-primary/40",
  Reserved: "bg-warning/15 text-warning-foreground border-warning/40",
  Paid: "bg-success/15 text-success border-success/40",
  Unavailable: "bg-destructive/12 text-destructive border-destructive/40",
};

export function StatusBadge({ status, className }: { status: string; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium",
        MAP[status] ?? "bg-muted text-muted-foreground border-border",
        className,
      )}
    >
      {status}
    </span>
  );
}
