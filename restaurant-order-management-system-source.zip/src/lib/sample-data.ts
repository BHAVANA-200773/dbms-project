import type {
  Customer,
  FoodItem,
  Order,
  OrderStatus,
  RestaurantTable,
  Settings,
} from "./types";

export const defaultSettings: Settings = {
  name: "Spice Garden Restaurant",
  address: "12-4-98, MG Road, Hyderabad, Telangana 500001",
  phone: "+91 98490 12345",
  email: "hello@spicegarden.in",
  taxPercent: 5,
  currency: "₹",
  notifyOrders: true,
  notifyPayments: true,
  staffName: "Ravi Kumar",
};

export const foodItems: FoodItem[] = [
  { id: "F001", name: "Chicken Biryani", category: "Biryani", description: "Dum-cooked basmati rice with tender chicken and saffron.", price: 280, emoji: "🍛", available: true },
  { id: "F002", name: "Veg Biryani", category: "Biryani", description: "Fragrant rice with garden vegetables and whole spices.", price: 220, emoji: "🥘", available: true },
  { id: "F003", name: "Mutton Biryani", category: "Biryani", description: "Slow-cooked mutton layered with long grain rice.", price: 360, emoji: "🍲", available: true },
  { id: "F004", name: "Chicken 65", category: "Starters", description: "Spicy deep-fried chicken with curry leaves.", price: 240, emoji: "🍗", available: true },
  { id: "F005", name: "Paneer Tikka", category: "Starters", description: "Char-grilled cottage cheese with peppers.", price: 230, emoji: "🧀", available: true },
  { id: "F006", name: "Gobi Manchurian", category: "Chinese", description: "Crispy cauliflower tossed in spicy manchurian sauce.", price: 180, emoji: "🥦", available: true },
  { id: "F007", name: "Paneer Butter Masala", category: "Main Course", description: "Cottage cheese simmered in rich tomato butter gravy.", price: 260, emoji: "🍛", available: true },
  { id: "F008", name: "Butter Naan", category: "Main Course", description: "Soft tandoori naan brushed with butter.", price: 45, emoji: "🫓", available: true },
  { id: "F009", name: "Dal Tadka", category: "Main Course", description: "Yellow lentils tempered with ghee and cumin.", price: 170, emoji: "🥣", available: true },
  { id: "F010", name: "Chicken Fried Rice", category: "Chinese", description: "Wok-tossed rice with chicken and spring onion.", price: 210, emoji: "🍚", available: true },
  { id: "F011", name: "Veg Fried Rice", category: "Chinese", description: "Classic street-style veg fried rice.", price: 170, emoji: "🍚", available: true },
  { id: "F012", name: "Chicken Noodles", category: "Chinese", description: "Hakka noodles with shredded chicken.", price: 200, emoji: "🍜", available: true },
  { id: "F013", name: "Margherita Pizza", category: "Pizza", description: "Wood-fired base, mozzarella and basil.", price: 299, emoji: "🍕", available: true },
  { id: "F014", name: "Paneer Tikka Pizza", category: "Pizza", description: "Tandoori paneer, onion and capsicum.", price: 349, emoji: "🍕", available: true },
  { id: "F015", name: "Chicken Burger", category: "Burgers", description: "Crispy chicken patty with house sauce.", price: 189, emoji: "🍔", available: true },
  { id: "F016", name: "Veg Burger", category: "Burgers", description: "Masala veg patty, lettuce and cheese.", price: 149, emoji: "🍔", available: true },
  { id: "F017", name: "French Fries", category: "Starters", description: "Golden salted fries with peri-peri dust.", price: 120, emoji: "🍟", available: true },
  { id: "F018", name: "Gulab Jamun", category: "Desserts", description: "Warm milk dumplings in cardamom syrup.", price: 90, emoji: "🍮", available: true },
  { id: "F019", name: "Ice Cream Sundae", category: "Desserts", description: "Vanilla scoops with nuts and chocolate.", price: 130, emoji: "🍨", available: true },
  { id: "F020", name: "Fresh Lime Soda", category: "Beverages", description: "Chilled lime soda, sweet or salted.", price: 70, emoji: "🥤", available: true },
  { id: "F021", name: "Filter Coffee", category: "Beverages", description: "South Indian filter coffee.", price: 60, emoji: "☕", available: true },
  { id: "F022", name: "Masala Tea", category: "Beverages", description: "Spiced tea brewed with ginger.", price: 40, emoji: "🍵", available: true },
  { id: "F023", name: "Soft Drink", category: "Beverages", description: "Chilled 300ml bottle.", price: 50, emoji: "🥤", available: false },
];

export const tables: RestaurantTable[] = Array.from({ length: 10 }, (_, i) => ({
  id: `T${i + 1}`,
  number: i + 1,
  capacity: [2, 2, 4, 4, 4, 6, 6, 8, 4, 2][i]!,
  status: "Available" as const,
}));

export const customers: Customer[] = [
  { id: "C001", name: "Arjun Reddy", phone: "+91 98765 43210", email: "arjun@mail.com" },
  { id: "C002", name: "Sneha Sharma", phone: "+91 90000 11223", email: "sneha@mail.com" },
  { id: "C003", name: "Vikram Rao", phone: "+91 91234 56780", email: "vikram@mail.com" },
  { id: "C004", name: "Divya Menon", phone: "+91 99887 76655", email: "divya@mail.com" },
  { id: "C005", name: "Imran Khan", phone: "+91 98111 22334", email: "imran@mail.com" },
  { id: "C006", name: "Priya Nair", phone: "+91 97000 55443", email: "priya@mail.com" },
  { id: "C007", name: "Rahul Verma", phone: "+91 93456 11220", email: "rahul@mail.com" },
  { id: "C008", name: "Anita Desai", phone: "+91 90909 80808", email: "anita@mail.com" },
  { id: "C009", name: "Kiran Babu", phone: "+91 96321 45870", email: "kiran@mail.com" },
  { id: "C010", name: "Meera Iyer", phone: "+91 95555 67890", email: "meera@mail.com" },
];

function daysAgo(d: number, hour: number) {
  const date = new Date();
  date.setDate(date.getDate() - d);
  date.setHours(hour, (hour * 7) % 60, 0, 0);
  return date.toISOString();
}

const pick = (id: string, qty: number) => {
  const f = foodItems.find((x) => x.id === id)!;
  return { itemId: f.id, name: f.name, price: f.price, quantity: qty };
};

const statuses: OrderStatus[] = [
  "Completed", "Completed", "Completed", "Served", "Ready",
  "Preparing", "Confirmed", "Pending", "Cancelled", "Completed",
  "Completed", "Preparing", "Pending", "Completed", "Served",
];

export const orders: Order[] = statuses.map((status, i) => {
  const customer = customers[i % customers.length]!;
  const itemSets = [
    [pick("F001", 2), pick("F008", 3)],
    [pick("F013", 1), pick("F020", 2)],
    [pick("F004", 1), pick("F010", 1), pick("F021", 2)],
    [pick("F007", 1), pick("F008", 4), pick("F018", 2)],
    [pick("F015", 2), pick("F017", 1)],
    [pick("F003", 1), pick("F019", 1)],
    [pick("F012", 2), pick("F006", 1)],
    [pick("F002", 2), pick("F022", 2)],
  ];
  return {
    id: `ORD${String(1001 + i)}`,
    customerId: customer.id,
    customerName: customer.name,
    tableId: `T${(i % 10) + 1}`,
    items: itemSets[i % itemSets.length]!,
    notes: i % 4 === 0 ? "Less spicy, please." : "",
    discount: i % 5 === 0 ? 50 : 0,
    status,
    createdAt: daysAgo(i < 5 ? 0 : i % 7, 10 + (i % 11)),
    paymentMethod: (["Cash", "Card", "UPI"] as const)[i % 3]!,
    paymentStatus: status === "Completed" ? "Paid" : "Pending",
  };
});

// Mark tables busy for active orders
for (const o of orders) {
  if (!["Completed", "Cancelled"].includes(o.status)) {
    const t = tables.find((t) => t.id === o.tableId);
    if (t) t.status = "Occupied";
  }
}
tables[8]!.status = "Reserved";
