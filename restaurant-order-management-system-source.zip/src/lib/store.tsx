import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import * as seed from "./sample-data";
import type {
  Customer,
  FoodItem,
  Order,
  OrderStatus,
  RestaurantTable,
  Settings,
  TableStatus,
} from "./types";

const KEY = "roms-data-v1";
const AUTH_KEY = "roms-auth-v1";

interface Data {
  foods: FoodItem[];
  orders: Order[];
  tables: RestaurantTable[];
  customers: Customer[];
  settings: Settings;
}

const initial = (): Data => ({
  foods: seed.foodItems,
  orders: seed.orders,
  tables: seed.tables,
  customers: seed.customers,
  settings: seed.defaultSettings,
});

interface StoreValue extends Data {
  ready: boolean;
  user: string | null;
  login: (email: string, password: string, remember: boolean) => boolean;
  logout: () => void;
  saveFood: (f: FoodItem) => void;
  deleteFood: (id: string) => void;
  saveCustomer: (c: Customer) => void;
  deleteCustomer: (id: string) => void;
  saveOrder: (o: Order) => void;
  setOrderStatus: (id: string, status: OrderStatus) => void;
  setPayment: (id: string, patch: Partial<Order>) => void;
  setTableStatus: (id: string, status: TableStatus) => void;
  saveSettings: (s: Settings) => void;
  resetData: () => void;
  nextId: (prefix: string, list: { id: string }[]) => string;
}

const StoreContext = createContext<StoreValue | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<Data>(initial);
  const [user, setUser] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setData({ ...initial(), ...JSON.parse(raw) });
      setUser(localStorage.getItem(AUTH_KEY));
    } catch {
      /* ignore */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready) localStorage.setItem(KEY, JSON.stringify(data));
  }, [data, ready]);

  const value = useMemo<StoreValue>(() => {
    const patch = (p: Partial<Data>) => setData((d) => ({ ...d, ...p }));
    return {
      ...data,
      ready,
      user,
      login: (email, password, remember) => {
        if (email.trim().toLowerCase() === "admin@spicegarden.in" && password === "admin123") {
          setUser(email.trim());
          if (remember) localStorage.setItem(AUTH_KEY, email.trim());
          return true;
        }
        return false;
      },
      logout: () => {
        setUser(null);
        localStorage.removeItem(AUTH_KEY);
      },
      saveFood: (f) =>
        setData((d) => ({
          ...d,
          foods: d.foods.some((x) => x.id === f.id)
            ? d.foods.map((x) => (x.id === f.id ? f : x))
            : [f, ...d.foods],
        })),
      deleteFood: (id) => setData((d) => ({ ...d, foods: d.foods.filter((f) => f.id !== id) })),
      saveCustomer: (c) =>
        setData((d) => ({
          ...d,
          customers: d.customers.some((x) => x.id === c.id)
            ? d.customers.map((x) => (x.id === c.id ? c : x))
            : [c, ...d.customers],
        })),
      deleteCustomer: (id) =>
        setData((d) => ({ ...d, customers: d.customers.filter((c) => c.id !== id) })),
      saveOrder: (o) =>
        setData((d) => ({
          ...d,
          orders: d.orders.some((x) => x.id === o.id)
            ? d.orders.map((x) => (x.id === o.id ? o : x))
            : [o, ...d.orders],
          tables: d.tables.map((t) =>
            t.id === o.tableId && !["Completed", "Cancelled"].includes(o.status)
              ? { ...t, status: "Occupied" }
              : t,
          ),
        })),
      setOrderStatus: (id, status) =>
        setData((d) => {
          const orders = d.orders.map((o) => (o.id === id ? { ...o, status } : o));
          const order = orders.find((o) => o.id === id);
          const tables = d.tables.map((t) => {
            if (!order || t.id !== order.tableId) return t;
            if (["Completed", "Cancelled"].includes(status)) return { ...t, status: "Available" as TableStatus };
            return { ...t, status: "Occupied" as TableStatus };
          });
          return { ...d, orders, tables };
        }),
      setPayment: (id, p) =>
        setData((d) => ({
          ...d,
          orders: d.orders.map((o) => (o.id === id ? { ...o, ...p } : o)),
        })),
      setTableStatus: (id, status) =>
        setData((d) => ({
          ...d,
          tables: d.tables.map((t) => (t.id === id ? { ...t, status } : t)),
        })),
      saveSettings: (s) => patch({ settings: s }),
      resetData: () => setData(initial()),
      nextId: (prefix, list) => {
        const nums = list
          .map((x) => parseInt(x.id.replace(/\D/g, ""), 10))
          .filter((n) => !Number.isNaN(n));
        const next = (nums.length ? Math.max(...nums) : 0) + 1;
        return `${prefix}${String(next).padStart(3, "0")}`;
      },
    };
  }, [data, ready, user]);

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used inside StoreProvider");
  return ctx;
}
