export type Category =
  | "Starters"
  | "Main Course"
  | "Biryani"
  | "Chinese"
  | "Pizza"
  | "Burgers"
  | "Desserts"
  | "Beverages";

export const CATEGORIES: Category[] = [
  "Starters",
  "Main Course",
  "Biryani",
  "Chinese",
  "Pizza",
  "Burgers",
  "Desserts",
  "Beverages",
];

export interface FoodItem {
  id: string;
  name: string;
  category: Category;
  description: string;
  price: number;
  emoji: string;
  available: boolean;
}

export type OrderStatus =
  | "Pending"
  | "Confirmed"
  | "Preparing"
  | "Ready"
  | "Served"
  | "Completed"
  | "Cancelled";

export const ORDER_STATUSES: OrderStatus[] = [
  "Pending",
  "Confirmed",
  "Preparing",
  "Ready",
  "Served",
  "Completed",
  "Cancelled",
];

export type TableStatus = "Available" | "Occupied" | "Reserved";
export type PaymentMethod = "Cash" | "Card" | "UPI";
export type PaymentStatus = "Paid" | "Pending";

export interface OrderItem {
  itemId: string;
  name: string;
  price: number;
  quantity: number;
}

export interface Order {
  id: string;
  customerId: string;
  customerName: string;
  tableId: string;
  items: OrderItem[];
  notes: string;
  discount: number;
  status: OrderStatus;
  createdAt: string;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
}

export interface RestaurantTable {
  id: string;
  number: number;
  capacity: number;
  status: TableStatus;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email: string;
}

export interface Settings {
  name: string;
  address: string;
  phone: string;
  email: string;
  taxPercent: number;
  currency: string;
  notifyOrders: boolean;
  notifyPayments: boolean;
  staffName: string;
}

export function money(n: number, currency = "₹") {
  return `${currency}${n.toLocaleString("en-IN", { maximumFractionDigits: 2 })}`;
}

export function orderTotals(order: Order, taxPercent: number) {
  const subtotal = order.items.reduce((s, i) => s + i.price * i.quantity, 0);
  const tax = (subtotal * taxPercent) / 100;
  const discount = order.discount || 0;
  return { subtotal, tax, discount, total: Math.max(0, subtotal + tax - discount) };
}
