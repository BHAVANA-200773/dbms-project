import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Pencil, Plus, ReceiptText } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { AppLayout } from "@/components/AppLayout";
import { OrderDialog } from "@/components/OrderDialog";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useStore } from "@/lib/store";
import { ORDER_STATUSES, money, orderTotals, type Order, type OrderStatus } from "@/lib/types";

export const Route = createFileRoute("/orders")({
  head: () => ({
    meta: [
      { title: "Orders — Restaurant Order Management" },
      {
        name: "description",
        content: "Create orders, add items, apply discounts and update order status in real time.",
      },
      { property: "og:title", content: "Orders — Restaurant Order Management" },
      {
        property: "og:description",
        content: "Create orders, add items, apply discounts and update order status in real time.",
      },
    ],
  }),
  component: OrdersPage,
});

function OrdersPage() {
  const { orders, settings, setOrderStatus } = useStore();
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<string>("all");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Order | null>(null);

  const filtered = useMemo(
    () =>
      [...orders]
        .filter(
          (o) =>
            (status === "all" || o.status === status) &&
            `${o.id} ${o.customerName} ${o.tableId} ${o.items.map((i) => i.name).join(" ")}`
              .toLowerCase()
              .includes(search.trim().toLowerCase()),
        )
        .sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)),
    [orders, search, status],
  );

  return (
    <AppLayout
      title="Order Management"
      subtitle={`${orders.length} orders in total`}
      search={search}
      onSearch={setSearch}
      actions={
        <Button
          className="gap-2"
          onClick={() => {
            setEditing(null);
            setOpen(true);
          }}
        >
          <Plus className="h-4 w-4" /> <span className="hidden sm:inline">New Order</span>
        </Button>
      }
    >
      <div className="mb-4 flex flex-wrap gap-2">
        {["all", ...ORDER_STATUSES].map((s) => (
          <Button
            key={s}
            size="sm"
            variant={status === s ? "default" : "outline"}
            onClick={() => setStatus(s)}
          >
            {s === "all" ? "All" : s}
          </Button>
        ))}
      </div>

      <Card>
        <CardContent className="overflow-x-auto p-0">
          {filtered.length === 0 ? (
            <p className="py-16 text-center text-sm text-muted-foreground">
              No orders match your filters.
            </p>
          ) : (
            <table className="w-full min-w-[1000px] text-sm">
              <thead>
                <tr className="border-b bg-muted/50 text-left text-xs uppercase text-muted-foreground">
                  <th className="px-4 py-3">Order ID</th>
                  <th>Customer</th>
                  <th>Table</th>
                  <th>Items</th>
                  <th>Qty</th>
                  <th>Total</th>
                  <th>Status</th>
                  <th>Order Time</th>
                  <th className="px-4">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((o) => {
                  const qty = o.items.reduce((s, i) => s + i.quantity, 0);
                  return (
                    <tr key={o.id} className="border-b last:border-0 hover:bg-muted/40">
                      <td className="px-4 py-3 font-medium">{o.id}</td>
                      <td>{o.customerName}</td>
                      <td>Table {o.tableId.replace("T", "")}</td>
                      <td className="max-w-[220px] truncate text-muted-foreground">
                        {o.items.map((i) => `${i.name} ×${i.quantity}`).join(", ")}
                      </td>
                      <td>{qty}</td>
                      <td className="font-medium">
                        {money(orderTotals(o, settings.taxPercent).total, settings.currency)}
                      </td>
                      <td>
                        <StatusBadge status={o.status} />
                      </td>
                      <td className="whitespace-nowrap text-muted-foreground">
                        {new Date(o.createdAt).toLocaleString("en-IN", {
                          dateStyle: "medium",
                          timeStyle: "short",
                        })}
                      </td>
                      <td className="px-4">
                        <div className="flex items-center gap-2 py-2">
                          <Select
                            value={o.status}
                            onValueChange={(v) => {
                              setOrderStatus(o.id, v as OrderStatus);
                              toast.success(`${o.id} marked ${v}`);
                            }}
                          >
                            <SelectTrigger className="h-8 w-[130px]">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {ORDER_STATUSES.map((s) => (
                                <SelectItem key={s} value={s}>
                                  {s}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => {
                              setEditing(o);
                              setOpen(true);
                            }}
                            aria-label="Edit order"
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => navigate({ to: "/billing", search: { order: o.id } })}
                            aria-label="Open bill"
                          >
                            <ReceiptText className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>

      <OrderDialog open={open} onOpenChange={setOpen} order={editing} />
    </AppLayout>
  );
}
