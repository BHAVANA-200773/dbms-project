import { createFileRoute } from "@tanstack/react-router";
import { BadgeIndianRupee, Ban, CheckCircle2, ShoppingBag, Star, Tags, TrendingUp } from "lucide-react";
import { useMemo, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { AppLayout } from "@/components/AppLayout";
import { StatCard } from "@/components/StatCard";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useStore } from "@/lib/store";
import { money, orderTotals } from "@/lib/types";

export const Route = createFileRoute("/reports")({
  head: () => ({
    meta: [
      { title: "Reports & Analytics — Restaurant Order Management" },
      {
        name: "description",
        content: "Sales analytics with daily, weekly and monthly trends and best-selling dishes.",
      },
      { property: "og:title", content: "Reports & Analytics — Restaurant Order Management" },
      {
        property: "og:description",
        content: "Sales analytics with daily, weekly and monthly trends and best-selling dishes.",
      },
    ],
  }),
  component: ReportsPage,
});

const COLORS = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"];
type RangeKey = "today" | "week" | "month" | "custom";

function ReportsPage() {
  const { orders, foods, settings } = useStore();
  const [range, setRange] = useState<RangeKey>("month");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  const inRange = useMemo(() => {
    const now = new Date();
    const start = new Date(now);
    if (range === "today") start.setHours(0, 0, 0, 0);
    if (range === "week") start.setDate(now.getDate() - 7);
    if (range === "month") start.setDate(now.getDate() - 30);
    return orders.filter((o) => {
      const d = new Date(o.createdAt);
      if (range === "custom") {
        if (from && d < new Date(from)) return false;
        if (to && d > new Date(`${to}T23:59:59`)) return false;
        return true;
      }
      return d >= start;
    });
  }, [orders, range, from, to]);

  const valid = inRange.filter((o) => o.status !== "Cancelled");
  const totalSales = valid.reduce((s, o) => s + orderTotals(o, settings.taxPercent).total, 0);
  const completed = inRange.filter((o) => o.status === "Completed").length;
  const cancelled = inRange.filter((o) => o.status === "Cancelled").length;
  const avg = valid.length ? totalSales / valid.length : 0;

  const itemCounts = useMemo(() => {
    const map = new Map<string, number>();
    for (const o of valid) for (const i of o.items) map.set(i.name, (map.get(i.name) ?? 0) + i.quantity);
    return [...map].map(([name, qty]) => ({ name, qty })).sort((a, b) => b.qty - a.qty);
  }, [valid]);

  const catCounts = useMemo(() => {
    const map = new Map<string, number>();
    for (const o of valid)
      for (const i of o.items) {
        const c = foods.find((f) => f.id === i.itemId)?.category ?? "Other";
        map.set(c, (map.get(c) ?? 0) + i.quantity);
      }
    return [...map].map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  }, [valid, foods]);

  const statusCounts = useMemo(() => {
    const map = new Map<string, number>();
    for (const o of inRange) map.set(o.status, (map.get(o.status) ?? 0) + 1);
    return [...map].map(([name, value]) => ({ name, value }));
  }, [inRange]);

  const series = (buckets: number, step: "day" | "week" | "month") =>
    Array.from({ length: buckets }, (_, idx) => {
      const i = buckets - 1 - idx;
      const start = new Date();
      const end = new Date();
      if (step === "day") {
        start.setDate(start.getDate() - i);
        start.setHours(0, 0, 0, 0);
        end.setTime(start.getTime() + 86400000);
      } else if (step === "week") {
        start.setDate(start.getDate() - (i + 1) * 7);
        end.setDate(end.getDate() - i * 7);
      } else {
        start.setMonth(start.getMonth() - (i + 1));
        end.setMonth(end.getMonth() - i);
      }
      const label =
        step === "day"
          ? start.toLocaleDateString("en-IN", { weekday: "short" })
          : step === "week"
            ? `W-${i}`
            : start.toLocaleDateString("en-IN", { month: "short" });
      const sales = orders
        .filter((o) => {
          const d = new Date(o.createdAt);
          return o.status !== "Cancelled" && d >= start && d < end;
        })
        .reduce((s, o) => s + orderTotals(o, settings.taxPercent).total, 0);
      return { label, sales: Math.round(sales) };
    });

  const daily = useMemo(() => series(7, "day"), [orders, settings.taxPercent]);
  const weekly = useMemo(() => series(6, "week"), [orders, settings.taxPercent]);
  const monthly = useMemo(() => series(6, "month"), [orders, settings.taxPercent]);

  return (
    <AppLayout title="Reports & Analytics" subtitle="Sales performance at a glance">
      <Card className="mb-5">
        <CardContent className="flex flex-wrap items-end gap-3 p-4">
          {(
            [
              ["today", "Today"],
              ["week", "This Week"],
              ["month", "This Month"],
              ["custom", "Custom Range"],
            ] as [RangeKey, string][]
          ).map(([k, l]) => (
            <Button
              key={k}
              size="sm"
              variant={range === k ? "default" : "outline"}
              onClick={() => setRange(k)}
            >
              {l}
            </Button>
          ))}
          {range === "custom" && (
            <>
              <div className="space-y-1">
                <Label className="text-xs">From</Label>
                <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">To</Label>
                <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
              </div>
            </>
          )}
        </CardContent>
      </Card>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Total Sales"
          value={money(totalSales, settings.currency)}
          icon={BadgeIndianRupee}
        />
        <StatCard label="Total Orders" value={inRange.length} icon={ShoppingBag} />
        <StatCard label="Completed" value={completed} icon={CheckCircle2} />
        <StatCard label="Cancelled" value={cancelled} icon={Ban} />
        <StatCard
          label="Avg Order Value"
          value={money(avg, settings.currency)}
          icon={TrendingUp}
        />
        <StatCard label="Most Ordered Food" value={itemCounts[0]?.name ?? "—"} icon={Star} />
        <StatCard label="Best Selling Category" value={catCounts[0]?.name ?? "—"} icon={Tags} />
        <StatCard
          label="Items Sold"
          value={itemCounts.reduce((s, i) => s + i.qty, 0)}
          icon={ShoppingBag}
        />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <ChartCard title="Daily Sales">
          <LineChart data={daily}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="label" fontSize={12} stroke="var(--muted-foreground)" />
            <YAxis fontSize={12} stroke="var(--muted-foreground)" />
            <Tooltip formatter={(v: number) => money(v, settings.currency)} />
            <Line type="monotone" dataKey="sales" stroke="var(--chart-1)" strokeWidth={3} />
          </LineChart>
        </ChartCard>
        <ChartCard title="Weekly Sales">
          <BarChart data={weekly}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="label" fontSize={12} stroke="var(--muted-foreground)" />
            <YAxis fontSize={12} stroke="var(--muted-foreground)" />
            <Tooltip formatter={(v: number) => money(v, settings.currency)} />
            <Bar dataKey="sales" fill="var(--chart-2)" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ChartCard>
        <ChartCard title="Monthly Sales">
          <BarChart data={monthly}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="label" fontSize={12} stroke="var(--muted-foreground)" />
            <YAxis fontSize={12} stroke="var(--muted-foreground)" />
            <Tooltip formatter={(v: number) => money(v, settings.currency)} />
            <Bar dataKey="sales" fill="var(--chart-3)" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ChartCard>
        <ChartCard title="Orders by Category">
          <PieChart>
            <Pie data={catCounts} dataKey="value" nameKey="name" outerRadius={85} innerRadius={45} paddingAngle={2}>
              {catCounts.map((_, i) => (
                <Cell key={i} fill={COLORS[i % COLORS.length]} />
              ))}
            </Pie>
            <Legend />
            <Tooltip />
          </PieChart>
        </ChartCard>
        <ChartCard title="Order Status">
          <PieChart>
            <Pie data={statusCounts} dataKey="value" nameKey="name" outerRadius={85} innerRadius={45} paddingAngle={2}>
              {statusCounts.map((_, i) => (
                <Cell key={i} fill={COLORS[i % COLORS.length]} />
              ))}
            </Pie>
            <Legend />
            <Tooltip />
          </PieChart>
        </ChartCard>
        <ChartCard title="Top Selling Items">
          <BarChart data={itemCounts.slice(0, 6)} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis type="number" fontSize={12} stroke="var(--muted-foreground)" />
            <YAxis dataKey="name" type="category" width={120} fontSize={11} />
            <Tooltip />
            <Bar dataKey="qty" fill="var(--chart-4)" radius={[0, 6, 6, 0]} />
          </BarChart>
        </ChartCard>
      </div>
    </AppLayout>
  );
}

function ChartCard({ title, children }: { title: string; children: React.ReactElement }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">{title}</CardTitle>
      </CardHeader>
      <CardContent className="h-72">
        <ResponsiveContainer width="100%" height="100%">
          {children}
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
