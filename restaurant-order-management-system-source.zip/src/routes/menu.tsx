import { createFileRoute } from "@tanstack/react-router";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { AppLayout } from "@/components/AppLayout";
import { StatusBadge } from "@/components/StatusBadge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { useStore } from "@/lib/store";
import { CATEGORIES, money, type Category, type FoodItem } from "@/lib/types";

export const Route = createFileRoute("/menu")({
  head: () => ({
    meta: [
      { title: "Menu Management — Restaurant Order Management" },
      {
        name: "description",
        content: "Add, edit, search and manage availability of every dish on the restaurant menu.",
      },
      { property: "og:title", content: "Menu Management — Restaurant Order Management" },
      {
        property: "og:description",
        content: "Add, edit, search and manage availability of every dish on the restaurant menu.",
      },
    ],
  }),
  component: MenuPage,
});

const EMOJIS = ["🍛", "🍗", "🍕", "🍔", "🍜", "🍚", "🥘", "🥤", "☕", "🍨", "🍮", "🫓", "🍟", "🥦", "🧀"];

function MenuPage() {
  const { foods, settings, saveFood, deleteFood, nextId } = useStore();
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState<string>("all");
  const [editing, setEditing] = useState<FoodItem | null>(null);
  const [open, setOpen] = useState(false);
  const [confirmId, setConfirmId] = useState<string | null>(null);

  const filtered = useMemo(
    () =>
      foods.filter(
        (f) =>
          (category === "all" || f.category === category) &&
          `${f.name} ${f.description} ${f.category}`
            .toLowerCase()
            .includes(search.trim().toLowerCase()),
      ),
    [foods, search, category],
  );

  const startNew = () => {
    setEditing({
      id: nextId("F", foods),
      name: "",
      category: "Starters",
      description: "",
      price: 0,
      emoji: "🍛",
      available: true,
    });
    setOpen(true);
  };

  return (
    <AppLayout
      title="Menu Management"
      subtitle={`${foods.length} items on the menu`}
      search={search}
      onSearch={setSearch}
      actions={
        <Button className="gap-2" onClick={startNew}>
          <Plus className="h-4 w-4" /> <span className="hidden sm:inline">Add Food Item</span>
        </Button>
      }
    >
      <div className="mb-5 flex flex-wrap gap-2">
        {["all", ...CATEGORIES].map((c) => (
          <Button
            key={c}
            size="sm"
            variant={category === c ? "default" : "outline"}
            onClick={() => setCategory(c)}
          >
            {c === "all" ? "All Categories" : c}
          </Button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center text-muted-foreground">
            No food items match your search.
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4">
          {filtered.map((f) => (
            <Card key={f.id} className="card-hover overflow-hidden pt-0">
              <div className="surface-warm flex h-32 items-center justify-center text-6xl">
                {f.emoji}
              </div>
              <CardContent className="space-y-2 p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate font-semibold">{f.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {f.id} · {f.category}
                    </p>
                  </div>
                  <StatusBadge status={f.available ? "Available" : "Unavailable"} />
                </div>
                <p className="line-clamp-2 text-sm text-muted-foreground">{f.description}</p>
                <div className="flex items-center justify-between pt-1">
                  <span className="text-lg font-semibold text-primary">
                    {money(f.price, settings.currency)}
                  </span>
                  <div className="flex items-center gap-1">
                    <Switch
                      checked={f.available}
                      onCheckedChange={(v) => {
                        saveFood({ ...f, available: v });
                        toast.success(`${f.name} marked ${v ? "available" : "unavailable"}`);
                      }}
                      aria-label="Toggle availability"
                    />
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => {
                        setEditing(f);
                        setOpen(true);
                      }}
                      aria-label="Edit item"
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="text-destructive"
                      onClick={() => setConfirmId(f.id)}
                      aria-label="Delete item"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <FoodDialog
        open={open}
        onOpenChange={setOpen}
        item={editing}
        onSave={(f) => {
          saveFood(f);
          toast.success("Food item saved");
          setOpen(false);
        }}
      />

      <AlertDialog open={!!confirmId} onOpenChange={(v) => !v && setConfirmId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this food item?</AlertDialogTitle>
            <AlertDialogDescription>
              This removes the item from the menu. Existing orders are not affected.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (confirmId) deleteFood(confirmId);
                setConfirmId(null);
                toast.success("Food item deleted");
              }}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
}

function FoodDialog({
  open,
  onOpenChange,
  item,
  onSave,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  item: FoodItem | null;
  onSave: (f: FoodItem) => void;
}) {
  const [form, setForm] = useState<FoodItem | null>(item);
  const [error, setError] = useState("");

  if (open && form?.id !== item?.id) setForm(item);
  if (!open && form !== null && form.id !== item?.id) setForm(item);

  const current = form ?? item;
  if (!current) return null;

  const set = (p: Partial<FoodItem>) => setForm({ ...current, ...p });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{item && item.name ? "Edit Food Item" : "Add Food Item"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Item ID</Label>
              <Input value={current.id} disabled />
            </div>
            <div className="space-y-1.5">
              <Label>Price ({"₹"})</Label>
              <Input
                type="number"
                min={0}
                value={current.price}
                onChange={(e) => set({ price: Number(e.target.value) || 0 })}
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Food Name</Label>
            <Input value={current.name} onChange={(e) => set({ name: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label>Category</Label>
            <Select
              value={current.category}
              onValueChange={(v) => set({ category: v as Category })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {CATEGORIES.map((c) => (
                  <SelectItem key={c} value={c}>
                    {c}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Description</Label>
            <Textarea
              value={current.description}
              onChange={(e) => set({ description: e.target.value })}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Food image</Label>
            <div className="flex flex-wrap gap-2">
              {EMOJIS.map((e) => (
                <button
                  key={e}
                  type="button"
                  onClick={() => set({ emoji: e })}
                  className={`h-10 w-10 rounded-lg border text-xl transition-colors ${
                    current.emoji === e ? "border-primary bg-primary/10" : "hover:bg-muted"
                  }`}
                >
                  {e}
                </button>
              ))}
            </div>
          </div>
          <label className="flex items-center gap-3 text-sm">
            <Switch
              checked={current.available}
              onCheckedChange={(v) => set({ available: v })}
            />
            Available for ordering
          </label>
          {error && <p className="text-sm text-destructive">{error}</p>}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            onClick={() => {
              if (!current.name.trim()) return setError("Food name is required.");
              if (current.price <= 0) return setError("Price must be greater than zero.");
              setError("");
              onSave(current);
            }}
          >
            Save item
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
