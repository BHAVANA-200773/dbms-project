import { createFileRoute } from "@tanstack/react-router";
import { ChefHat, RotateCcw, Save } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { AppLayout } from "@/components/AppLayout";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useStore } from "@/lib/store";
import type { Settings } from "@/lib/types";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Settings — Restaurant Order Management" },
      {
        name: "description",
        content: "Update restaurant details, tax percentage, currency, profile and notifications.",
      },
      { property: "og:title", content: "Settings — Restaurant Order Management" },
      {
        property: "og:description",
        content: "Update restaurant details, tax percentage, currency, profile and notifications.",
      },
    ],
  }),
  component: SettingsPage,
});

const LOGOS = ["🍽️", "🍛", "🌶️", "👨‍🍳", "🥘", "🍕"];

function SettingsPage() {
  const { settings, saveSettings, resetData } = useStore();
  const [form, setForm] = useState<Settings>(settings);
  const [error, setError] = useState("");
  const set = (p: Partial<Settings>) => setForm({ ...form, ...p });

  const save = () => {
    if (!form.name.trim()) return setError("Restaurant name is required.");
    if (form.taxPercent < 0 || form.taxPercent > 50)
      return setError("Tax percentage must be between 0 and 50.");
    if (form.email && !/^\S+@\S+\.\S+$/.test(form.email))
      return setError("Enter a valid email address.");
    setError("");
    saveSettings(form);
    toast.success("Settings saved");
  };

  return (
    <AppLayout title="Settings" subtitle="Restaurant, profile and notification preferences">
      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Restaurant details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1.5">
              <Label>Restaurant name</Label>
              <Input value={form.name} onChange={(e) => set({ name: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label>Address</Label>
              <Input value={form.address} onChange={(e) => set({ address: e.target.value })} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Phone</Label>
                <Input value={form.phone} onChange={(e) => set({ phone: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label>Email</Label>
                <Input value={form.email} onChange={(e) => set({ email: e.target.value })} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Tax percentage (%)</Label>
                <Input
                  type="number"
                  min={0}
                  max={50}
                  value={form.taxPercent}
                  onChange={(e) => set({ taxPercent: Number(e.target.value) || 0 })}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Currency symbol</Label>
                <Input value={form.currency} onChange={(e) => set({ currency: e.target.value })} />
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-5">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Restaurant logo</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-wrap items-center gap-3">
              <div className="surface-warm flex h-16 w-16 items-center justify-center rounded-2xl text-3xl">
                <ChefHat className="h-7 w-7 text-primary" />
              </div>
              {LOGOS.map((l) => (
                <button
                  key={l}
                  onClick={() => toast.success("Logo updated")}
                  className="h-12 w-12 rounded-xl border text-2xl transition-colors hover:bg-muted"
                >
                  {l}
                </button>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Profile</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1.5">
                <Label>Staff name</Label>
                <Input
                  value={form.staffName}
                  onChange={(e) => set({ staffName: e.target.value })}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Notifications</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <label className="flex items-center justify-between text-sm">
                New order alerts
                <Switch
                  checked={form.notifyOrders}
                  onCheckedChange={(v) => set({ notifyOrders: v })}
                />
              </label>
              <label className="flex items-center justify-between text-sm">
                Payment received alerts
                <Switch
                  checked={form.notifyPayments}
                  onCheckedChange={(v) => set({ notifyPayments: v })}
                />
              </label>
            </CardContent>
          </Card>
        </div>
      </div>

      {error && <p className="mt-4 text-sm text-destructive">{error}</p>}

      <div className="mt-5 flex flex-wrap gap-3">
        <Button className="gap-2" onClick={save}>
          <Save className="h-4 w-4" /> Save settings
        </Button>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="outline" className="gap-2">
              <RotateCcw className="h-4 w-4" /> Reset demo data
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Reset all data?</AlertDialogTitle>
              <AlertDialogDescription>
                This restores the original sample menu, orders, tables and customers. Your changes
                will be lost.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={() => {
                  resetData();
                  setForm(settings);
                  toast.success("Demo data restored");
                }}
              >
                Reset
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </AppLayout>
  );
}
