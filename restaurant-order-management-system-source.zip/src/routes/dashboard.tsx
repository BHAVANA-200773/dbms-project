import { createFileRoute, Link } from "@tanstack/react-router";
import {
  CheckCircle2,
  Clock,
  IndianRupee,
  Plus,
  ShoppingBag,
  Table2,
  Users,
} from "lucide-react";
import { useMemo, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { AppLayout } from "@/components/AppLayout";
import { OrderDialog } from "@/components/OrderDialog";
import { StatCard } from "@/components/StatCard";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useStore } from "@/lib/store";
import { money, orderTotals } from "@/lib/types";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — Restaurant Order Management" },
      {
        name: "description",
        content: "Live restaurant dashboard with sales, orders, tables and recent activity.",
      },
      { property: "og:title", content: "Dashboard — Restaurant Order Management" },
      {
        property: "og:description",
        content: "Live restaurant dashboard with sales, orders, tables and recent activity.",
      },
    ],
  }),
  component: DashboardPage,
});

const COLORS = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"];

function DashboardPage() {
  const { orders, tables, foods, settings } = useStore();
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");

  const stats = useMemo(() => {
    const today = new Date().toDateString();
    const totalOf = (o: (typeof orders)[number]) => orderTotals(o, settings.taxPercent).total;
    const todaySales = orders
      .filter((o) => new Date(o.createdAt).toDateString() === today && o.status !== "Cancelled")
      .reduce((s, o) => s + totalOf(o), 0);
    return {
      total: orders.length,
      todaySales,
      pending: orders.filter((o) =>
        ["Pending", "Confirmed", "Preparing", "Ready"].includes(o.status),
      ).length,
      completed: orders.filter((o) => o.status === "Completed").length,
      available: tables.filter((t) => t.status === "Available").length,
      occupied: tables.filter((t) => t.status === "Occupied").length,
    };
  }, [orders, tables, settings.taxPercent]);

  const dailySales = useMemo(() => {
    const days = Array.from({ length: 7 }, (_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - (6 - i));
      return d;
    });
    return days.map((d) => ({
      day: d.toLocaleDateString("en-IN", { weekday: "short" }),
      sales: Math.round(
        orders
          .filter(
            (o) =>
              new Date(o.createdAt).toDateString() === d.toDateString() &&
              o.status !== "Cancelled",
          )
          .reduce((s, o) => s + orderTotals(o, settings.taxPercent).total, 0),
      ),
    }));
  }, [orders, settings.taxPercent]);

  const byCategory = useMemo(() => {
    const map = new Map<string, number>();
    for (const o of orders)
      for (const i of o.items) {
        const cat = foods.find((f) => f.id === i.itemId)?.category ?? "Other";
        map.set(cat, (map.get(cat) ?? 0) + i.quantity);
      }
    return [...map].map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  }, [orders, foods]);

  const byStatus = useMemo(() => {
    const map = new Map<string, number>();
    for (const o of orders) map.set(o.status, (map.get(o.status) ?? 0) + 1);
    return [...map].map(([name, value]) => ({ name, value }));
  }, [orders]);

  const recent = useMemo(
    () =>
      [...orders]
        .filter(
          (o) =>
            !search.trim() ||
            `${o.id} ${o.customerName} ${o.status}`.toLowerCase().includes(search.toLowerCase()),
        )
        .sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt))
        .slice(0, 8),
    [orders, search],
  );

  return (
    <AppLayout
      title="Dashboard"
      subtitle={`Welcome back, ${settings.staffName}`}
      search={search}
      onSearch={setSearch}
      actions={
        <Button onClick={() => setOpen(true)} className="gap-2">
          <Plus className="h-4 w-4" /> <span className="hidden sm:inline">Create New Order</span>
        </Button>
      }
    >
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        <StatCard label="Total Orders" value={stats.total} icon={ShoppingBag} />
        <StatCard
          label="Today's Sales"
          value={money(stats.todaySales, settings.currency)}
          icon={IndianRupee}
        />
        <StatCard label="Pending Orders" value={stats.pending} icon={Clock} />
        <StatCard label="Completed Orders" value={stats.completed} icon={CheckCircle2} />
        <StatCard label="Available Tables" value={stats.available} icon={Table2} />
        <StatCard label="Occupied Tables" value={stats.occupied} icon={Users} />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Daily Sales (last 7 days)</CardTitle>
          </CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={dailySales}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="day" stroke="var(--muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                <Tooltip formatter={(v: number) => money(v, settings.currency)} />
                <Line
                  type="monotone"
                  dataKey="sales"
                  stroke="var(--chart-1)"
                  strokeWidth={3}
                  dot={{ r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Order Status</CardTitle>
          </CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={byStatus} dataKey="value" nameKey="name" outerRadius={85} innerRadius={45} paddingAngle={2}>
                  {byStatus.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Legend />
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle className="text-base">Orders by Category</CardTitle>
          </CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={byCategory}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="name" stroke="var(--muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                <Tooltip />
                <Bar dataKey="value" fill="var(--chart-2)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card className="mt-6">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-base">Recent Orders</CardTitle>
          <Button asChild variant="outline" size="sm">
            <Link to="/orders">View all</Link>
          </Button>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          {recent.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted-foreground">No orders found.</p>
          ) : (
            <table className="w-full min-w-[760px] text-sm">
              <thead>
                <tr className="border-b text-left text-xs uppercase text-muted-foreground">
                  <th className="py-2">Order ID</th>
                  <th>Customer</th>
                  <th>Table</th>
                  <th>Items</th>
                  <th>Total</th>
                  <th>Status</th>
                  <th>Date &amp; Time</th>
                </tr>
              </thead>
              <tbody>
                {recent.map((o) => (
                  <tr key={o.id} className="border-b last:border-0 hover:bg-muted/50">
                    <td className="py-3 font-medium">{o.id}</td>
                    <td>{o.customerName}</td>
                    <td>Table {o.tableId.replace("T", "")}</td>
                    <td className="max-w-[220px] truncate text-muted-foreground">
                      {o.items.map((i) => `${i.name} ×${i.quantity}`).join(", ")}
                    </td>
                    <td className="font-medium">
                      {money(orderTotals(o, settings.taxPercent).total, settings.currency)}
                    </td>
                    <td>
                      <StatusBadge status={o.status} />
                    </td>
                    <td className="whitespace-nowrap text-muted-foreground">
                      {new Date(o.createdAt).toLocaleString("en-IN", {
                        dateStyle: "medium",
                        timeStyle: "short",
                      })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>

      <OrderDialog open={open} onOpenChange={setOpen} />
    </AppLayout>
  );
}
