import { createFileRoute } from "@tanstack/react-router";
import { History, Pencil, Plus, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { AppLayout } from "@/components/AppLayout";
import { StatusBadge } from "@/components/StatusBadge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useStore } from "@/lib/store";
import { money, orderTotals, type Customer } from "@/lib/types";

export const Route = createFileRoute("/customers")({
  head: () => ({
    meta: [
      { title: "Customers — Restaurant Order Management" },
      {
        name: "description",
        content: "Customer directory with order counts, total spend and full order history.",
      },
      { property: "og:title", content: "Customers — Restaurant Order Management" },
      {
        property: "og:description",
        content: "Customer directory with order counts, total spend and full order history.",
      },
    ],
  }),
  component: CustomersPage,
});

function CustomersPage() {
  const { customers, orders, settings, saveCustomer, deleteCustomer, nextId } = useStore();
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState<Customer | null>(null);
  const [open, setOpen] = useState(false);
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const [historyId, setHistoryId] = useState<string | null>(null);

  const rows = useMemo(
    () =>
      customers
        .filter((c) =>
          `${c.id} ${c.name} ${c.phone} ${c.email}`
            .toLowerCase()
            .includes(search.trim().toLowerCase()),
        )
        .map((c) => {
          const mine = orders.filter((o) => o.customerId === c.id && o.status !== "Cancelled");
          return {
            ...c,
            count: mine.length,
            spend: mine.reduce((s, o) => s + orderTotals(o, settings.taxPercent).total, 0),
            last: mine.length
              ? new Date(
                  Math.max(...mine.map((o) => +new Date(o.createdAt))),
                ).toLocaleDateString("en-IN")
              : "—",
          };
        }),
    [customers, orders, search, settings.taxPercent],
  );

  const history = orders.filter((o) => o.customerId === historyId);

  return (
    <AppLayout
      title="Customers"
      subtitle={`${customers.length} registered customers`}
      search={search}
      onSearch={setSearch}
      actions={
        <Button
          className="gap-2"
          onClick={() => {
            setEditing({ id: nextId("C", customers), name: "", phone: "", email: "" });
            setOpen(true);
          }}
        >
          <Plus className="h-4 w-4" /> <span className="hidden sm:inline">Add Customer</span>
        </Button>
      }
    >
      <Card>
        <CardContent className="overflow-x-auto p-0">
          {rows.length === 0 ? (
            <p className="py-16 text-center text-sm text-muted-foreground">No customers found.</p>
          ) : (
            <table className="w-full min-w-[860px] text-sm">
              <thead>
                <tr className="border-b bg-muted/50 text-left text-xs uppercase text-muted-foreground">
                  <th className="px-4 py-3">ID</th>
                  <th>Name</th>
                  <th>Phone</th>
                  <th>Orders</th>
                  <th>Total Spending</th>
                  <th>Last Order</th>
                  <th className="px-4">Actions</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((c) => (
                  <tr key={c.id} className="border-b last:border-0 hover:bg-muted/40">
                    <td className="px-4 py-3 font-medium">{c.id}</td>
                    <td>{c.name}</td>
                    <td className="text-muted-foreground">{c.phone}</td>
                    <td>{c.count}</td>
                    <td className="font-medium">{money(c.spend, settings.currency)}</td>
                    <td className="text-muted-foreground">{c.last}</td>
                    <td className="px-4">
                      <div className="flex gap-1 py-2">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => setHistoryId(c.id)}
                          aria-label="Order history"
                        >
                          <History className="h-4 w-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => {
                            setEditing(c);
                            setOpen(true);
                          }}
                          aria-label="Edit customer"
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="text-destructive"
                          onClick={() => setConfirmId(c.id)}
                          aria-label="Delete customer"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>

      <CustomerDialog
        open={open}
        onOpenChange={setOpen}
        customer={editing}
        onSave={(c) => {
          saveCustomer(c);
          toast.success("Customer saved");
          setOpen(false);
        }}
      />

      <Dialog open={!!historyId} onOpenChange={(v) => !v && setHistoryId(null)}>
        <DialogContent className="max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Order history</DialogTitle>
          </DialogHeader>
          {history.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted-foreground">No orders yet.</p>
          ) : (
            <div className="space-y-2">
              {history.map((o) => (
                <div key={o.id} className="flex items-center gap-3 rounded-lg border p-3 text-sm">
                  <div className="min-w-0 flex-1">
                    <p className="font-medium">{o.id}</p>
                    <p className="truncate text-xs text-muted-foreground">
                      {o.items.map((i) => `${i.name} ×${i.quantity}`).join(", ")}
                    </p>
                  </div>
                  <StatusBadge status={o.status} />
                  <span className="font-medium">
                    {money(orderTotals(o, settings.taxPercent).total, settings.currency)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!confirmId} onOpenChange={(v) => !v && setConfirmId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this customer?</AlertDialogTitle>
            <AlertDialogDescription>
              The customer record will be removed permanently.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (confirmId) deleteCustomer(confirmId);
                setConfirmId(null);
                toast.success("Customer deleted");
              }}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
}

function CustomerDialog({
  open,
  onOpenChange,
  customer,
  onSave,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  customer: Customer | null;
  onSave: (c: Customer) => void;
}) {
  const [form, setForm] = useState<Customer | null>(customer);
  const [error, setError] = useState("");
  if (form?.id !== customer?.id) setForm(customer);
  const current = form ?? customer;
  if (!current) return null;
  const set = (p: Partial<Customer>) => setForm({ ...current, ...p });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{customer?.name ? "Edit Customer" : "Add Customer"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label>Customer ID</Label>
            <Input value={current.id} disabled />
          </div>
          <div className="space-y-1.5">
            <Label>Name</Label>
            <Input value={current.name} onChange={(e) => set({ name: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label>Phone number</Label>
            <Input value={current.phone} onChange={(e) => set({ phone: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label>Email</Label>
            <Input value={current.email} onChange={(e) => set({ email: e.target.value })} />
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            onClick={() => {
              if (!current.name.trim()) return setError("Customer name is required.");
              if (!/^[\d+\s-]{8,}$/.test(current.phone.trim()))
                return setError("Enter a valid phone number.");
              if (current.email && !/^\S+@\S+\.\S+$/.test(current.email))
                return setError("Enter a valid email address.");
              setError("");
              onSave(current);
            }}
          >
            Save customer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
