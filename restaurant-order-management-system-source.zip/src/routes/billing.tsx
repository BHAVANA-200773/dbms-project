import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { CheckCircle2, Download, Printer } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { z } from "zod";
import { AppLayout } from "@/components/AppLayout";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useStore } from "@/lib/store";
import { money, orderTotals, type PaymentMethod } from "@/lib/types";

export const Route = createFileRoute("/billing")({
  validateSearch: z.object({ order: z.string().optional() }),
  head: () => ({
    meta: [
      { title: "Billing & Payments — Restaurant Order Management" },
      {
        name: "description",
        content: "Generate restaurant bills, print or download invoices and record payments.",
      },
      { property: "og:title", content: "Billing & Payments — Restaurant Order Management" },
      {
        property: "og:description",
        content: "Generate restaurant bills, print or download invoices and record payments.",
      },
    ],
  }),
  component: BillingPage,
});

function BillingPage() {
  const { orders, settings, setPayment } = useStore();
  const { order: orderParam } = Route.useSearch();
  const navigate = useNavigate();
  const [search, setSearch] = useState("");

  const billable = useMemo(
    () =>
      [...orders]
        .filter((o) => o.status !== "Cancelled")
        .filter((o) =>
          `${o.id} ${o.customerName}`.toLowerCase().includes(search.trim().toLowerCase()),
        )
        .sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)),
    [orders, search],
  );

  const selectedId = orderParam ?? billable[0]?.id;
  const order = orders.find((o) => o.id === selectedId) ?? null;
  const totals = order ? orderTotals(order, settings.taxPercent) : null;

  const download = () => {
    if (!order || !totals) return;
    const lines = [
      settings.name,
      settings.address,
      `Phone: ${settings.phone}`,
      "------------------------------------",
      `Bill No: BILL-${order.id}`,
      `Date: ${new Date(order.createdAt).toLocaleDateString("en-IN")}`,
      `Time: ${new Date(order.createdAt).toLocaleTimeString("en-IN")}`,
      `Customer: ${order.customerName}`,
      `Table: ${order.tableId.replace("T", "")}`,
      "------------------------------------",
      ...order.items.map(
        (i) => `${i.name} x${i.quantity}  ${money(i.price * i.quantity, settings.currency)}`,
      ),
      "------------------------------------",
      `Subtotal: ${money(totals.subtotal, settings.currency)}`,
      `Tax (${settings.taxPercent}%): ${money(totals.tax, settings.currency)}`,
      `Discount: -${money(totals.discount, settings.currency)}`,
      `Grand Total: ${money(totals.total, settings.currency)}`,
      `Payment: ${order.paymentMethod} (${order.paymentStatus})`,
      "",
      "Thank you, visit again!",
    ].join("\n");
    const url = URL.createObjectURL(new Blob([lines], { type: "text/plain" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `BILL-${order.id}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Bill downloaded");
  };

  return (
    <AppLayout
      title="Billing & Payments"
      subtitle="Generate bills and record payments"
      search={search}
      onSearch={setSearch}
    >
      <div className="grid gap-5 lg:grid-cols-[320px_1fr]">
        <Card className="no-print h-fit">
          <CardContent className="max-h-[70vh] space-y-1 overflow-y-auto p-3">
            {billable.length === 0 && (
              <p className="py-10 text-center text-sm text-muted-foreground">No bills found.</p>
            )}
            {billable.map((o) => (
              <button
                key={o.id}
                onClick={() => navigate({ to: "/billing", search: { order: o.id } })}
                className={`flex w-full items-center gap-2 rounded-lg px-3 py-2.5 text-left text-sm transition-colors ${
                  o.id === selectedId ? "bg-primary/10 text-primary" : "hover:bg-muted"
                }`}
              >
                <div className="min-w-0 flex-1">
                  <p className="font-medium">{o.id}</p>
                  <p className="truncate text-xs text-muted-foreground">{o.customerName}</p>
                </div>
                <StatusBadge status={o.paymentStatus} />
              </button>
            ))}
          </CardContent>
        </Card>

        {!order || !totals ? (
          <Card>
            <CardContent className="py-20 text-center text-muted-foreground">
              Select an order to view its bill.
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            <Card>
              <CardContent className="p-6 sm:p-8">
                <div className="text-center">
                  <h2 className="font-display text-2xl font-bold">{settings.name}</h2>
                  <p className="text-sm text-muted-foreground">{settings.address}</p>
                  <p className="text-sm text-muted-foreground">Phone: {settings.phone}</p>
                </div>
                <div className="my-5 grid grid-cols-2 gap-2 border-y py-4 text-sm sm:grid-cols-4">
                  <Field label="Bill No" value={`BILL-${order.id}`} />
                  <Field
                    label="Date"
                    value={new Date(order.createdAt).toLocaleDateString("en-IN")}
                  />
                  <Field
                    label="Time"
                    value={new Date(order.createdAt).toLocaleTimeString("en-IN", {
                      timeStyle: "short",
                    })}
                  />
                  <Field label="Table" value={`Table ${order.tableId.replace("T", "")}`} />
                  <Field label="Customer" value={order.customerName} />
                  <Field label="Order status" value={order.status} />
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full min-w-[420px] text-sm">
                    <thead>
                      <tr className="border-b text-left text-xs uppercase text-muted-foreground">
                        <th className="py-2">Item</th>
                        <th className="text-center">Qty</th>
                        <th className="text-right">Price</th>
                        <th className="text-right">Amount</th>
                      </tr>
                    </thead>
                    <tbody>
                      {order.items.map((i) => (
                        <tr key={i.itemId} className="border-b last:border-0">
                          <td className="py-2">{i.name}</td>
                          <td className="text-center">{i.quantity}</td>
                          <td className="text-right">{money(i.price, settings.currency)}</td>
                          <td className="text-right font-medium">
                            {money(i.price * i.quantity, settings.currency)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="ml-auto mt-5 max-w-xs space-y-1 text-sm">
                  <Row label="Subtotal" value={money(totals.subtotal, settings.currency)} />
                  <Row
                    label={`Tax (${settings.taxPercent}%)`}
                    value={money(totals.tax, settings.currency)}
                  />
                  <Row label="Discount" value={`- ${money(totals.discount, settings.currency)}`} />
                  <div className="flex justify-between border-t pt-2 text-lg font-semibold">
                    <span>Grand Total</span>
                    <span className="text-primary">{money(totals.total, settings.currency)}</span>
                  </div>
                </div>

                {order.notes && (
                  <p className="mt-4 rounded-lg bg-muted/60 p-3 text-sm text-muted-foreground">
                    Note: {order.notes}
                  </p>
                )}
                <p className="mt-6 text-center text-sm text-muted-foreground">
                  Thank you for dining with us!
                </p>
              </CardContent>
            </Card>

            <Card className="no-print">
              <CardContent className="flex flex-wrap items-end gap-4 p-5">
                <div className="w-44 space-y-1.5">
                  <Label>Payment method</Label>
                  <Select
                    value={order.paymentMethod}
                    onValueChange={(v) => {
                      setPayment(order.id, { paymentMethod: v as PaymentMethod });
                      toast.success(`Payment method set to ${v}`);
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {["Cash", "Card", "UPI"].map((m) => (
                        <SelectItem key={m} value={m}>
                          {m}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Payment status</Label>
                  <div>
                    <StatusBadge status={order.paymentStatus} />
                  </div>
                </div>
                <div className="ml-auto flex flex-wrap gap-2">
                  <Button variant="outline" className="gap-2" onClick={() => window.print()}>
                    <Printer className="h-4 w-4" /> Print Bill
                  </Button>
                  <Button variant="outline" className="gap-2" onClick={download}>
                    <Download className="h-4 w-4" /> Download Bill
                  </Button>
                  <Button
                    className="gap-2"
                    disabled={order.paymentStatus === "Paid"}
                    onClick={() => {
                      setPayment(order.id, { paymentStatus: "Paid" });
                      toast.success(`${order.id} marked as paid`);
                    }}
                  >
                    <CheckCircle2 className="h-4 w-4" /> Mark as Paid
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </AppLayout>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs uppercase text-muted-foreground">{label}</p>
      <p className="font-medium">{value}</p>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between text-muted-foreground">
      <span>{label}</span>
      <span className="font-medium text-foreground">{value}</span>
    </div>
  );
}
