import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ChefHat, Eye, EyeOff, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Login — Spice Garden Restaurant Order Management" },
      {
        name: "description",
        content:
          "Staff login for the Spice Garden Restaurant Order Management System: orders, menu, tables, billing and reports.",
      },
      { property: "og:title", content: "Spice Garden Restaurant Order Management" },
      {
        property: "og:description",
        content: "Manage restaurant orders, menu, tables, billing and sales reports in one place.",
      },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const { login, user, ready } = useStore();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [remember, setRemember] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (ready && user) navigate({ to: "/dashboard", replace: true });
  }, [ready, user, navigate]);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!email.trim() || !password) {
      setError("Please enter both email and password.");
      return;
    }
    setLoading(true);
    setTimeout(() => {
      const ok = login(email, password, remember);
      setLoading(false);
      if (ok) {
        toast.success("Welcome back!");
        navigate({ to: "/dashboard" });
      } else {
        setError("Invalid credentials. Use the demo login shown below.");
      }
    }, 450);
  };

  return (
    <div className="flex min-h-screen flex-col lg:flex-row">
      <div className="surface-warm relative hidden flex-1 items-center justify-center bg-sidebar p-12 lg:flex">
        <div className="max-w-md text-sidebar-foreground">
          <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-sidebar-primary text-sidebar-primary-foreground">
            <ChefHat className="h-8 w-8" />
          </div>
          <h2 className="font-display text-4xl font-bold leading-tight">
            Run your restaurant from one dashboard.
          </h2>
          <p className="mt-4 text-sidebar-foreground/70">
            Orders, menu, tables, billing, customers and sales reports — everything your floor staff
            needs, in real time.
          </p>
          <div className="mt-8 grid grid-cols-3 gap-4 text-center text-sidebar-foreground/80">
            {[
              ["🍛", "Menu"],
              ["🧾", "Billing"],
              ["📊", "Reports"],
            ].map(([e, l]) => (
              <div key={l} className="rounded-xl bg-sidebar-accent/60 py-4">
                <div className="text-2xl">{e}</div>
                <div className="mt-1 text-xs">{l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="flex flex-1 items-center justify-center px-5 py-12">
        <div className="w-full max-w-sm">
          <div className="mb-8 text-center">
            <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground">
              <ChefHat className="h-7 w-7" />
            </div>
            <h1 className="font-display text-2xl font-bold">Restaurant Order Management System</h1>
            <p className="mt-1 text-sm text-muted-foreground">Sign in to continue to dashboard</p>
          </div>

          <form onSubmit={submit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="email">Username / Email</Label>
              <Input
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@spicegarden.in"
                autoComplete="username"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={show ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  autoComplete="current-password"
                  className="pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShow((s) => !s)}
                  aria-label={show ? "Hide password" : "Show password"}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                >
                  {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <label className="flex items-center gap-2 text-sm">
              <Checkbox checked={remember} onCheckedChange={(v) => setRemember(Boolean(v))} />
              Remember me
            </label>

            {error && (
              <p className="rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
                {error}
              </p>
            )}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Login
            </Button>
          </form>

          <div className="mt-6 rounded-xl border border-dashed bg-muted/50 p-4 text-sm">
            <p className="font-medium">Demo credentials</p>
            <p className="mt-1 text-muted-foreground">Email: admin@spicegarden.in</p>
            <p className="text-muted-foreground">Password: admin123</p>
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="mt-3 w-full"
              onClick={() => {
                setEmail("admin@spicegarden.in");
                setPassword("admin123");
              }}
            >
              Fill demo credentials
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
