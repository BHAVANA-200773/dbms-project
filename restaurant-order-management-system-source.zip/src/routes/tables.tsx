import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Plus, Users } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { AppLayout } from "@/components/AppLayout";
import { OrderDialog } from "@/components/OrderDialog";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useStore } from "@/lib/store";
import { money, orderTotals, type TableStatus } from "@/lib/types";

export const Route = createFileRoute("/tables")({
  head: () => ({
    meta: [
      { title: "Tables — Restaurant Order Management" },
      {
        name: "description",
        content: "Track table availability, seating capacity and the live order on every table.",
      },
      { property: "og:title", content: "Tables — Restaurant Order Management" },
      {
        property: "og:description",
        content: "Track table availability, seating capacity and the live order on every table.",
      },
    ],
  }),
  component: TablesPage,
});

const STATUSES: TableStatus[] = ["Available", "Occupied", "Reserved"];

function TablesPage() {
  const { tables, orders, settings, setTableStatus } = useStore();
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<string>("all");
  const [newFor, setNewFor] = useState<string | null>(null);

  const activeOrderFor = (tableId: string) =>
    orders.find(
      (o) => o.tableId === tableId && !["Completed", "Cancelled"].includes(o.status),
    );

  const filtered = useMemo(
    () =>
      tables.filter(
        (t) =>
          (filter === "all" || t.status === filter) &&
          `table ${t.number} ${t.status}`.toLowerCase().includes(search.trim().toLowerCase()),
      ),
    [tables, filter, search],
  );

  return (
    <AppLayout
      title="Table Management"
      subtitle={`${tables.filter((t) => t.status === "Available").length} of ${tables.length} tables free`}
      search={search}
      onSearch={setSearch}
    >
      <div className="mb-5 flex flex-wrap gap-2">
        {["all", ...STATUSES].map((s) => (
          <Button
            key={s}
            size="sm"
            variant={filter === s ? "default" : "outline"}
            onClick={() => setFilter(s)}
          >
            {s === "all" ? "All Tables" : s}
          </Button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center text-muted-foreground">
            No tables match your filters.
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4">
          {filtered.map((t) => {
            const order = activeOrderFor(t.id);
            return (
              <Card key={t.id} className="card-hover">
                <CardContent className="space-y-3 p-5">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="font-display text-xl font-semibold">Table {t.number}</p>
                      <p className="flex items-center gap-1 text-xs text-muted-foreground">
                        <Users className="h-3 w-3" /> {t.capacity} seats
                      </p>
                    </div>
                    <StatusBadge status={t.status} />
                  </div>

                  <div className="rounded-lg bg-muted/60 p-3 text-sm">
                    {order ? (
                      <>
                        <p className="font-medium">{order.id}</p>
                        <p className="text-muted-foreground">{order.customerName}</p>
                        <p className="mt-1 font-medium text-primary">
                          {money(
                            orderTotals(order, settings.taxPercent).total,
                            settings.currency,
                          )}
                        </p>
                      </>
                    ) : (
                      <p className="text-muted-foreground">No active order</p>
                    )}
                  </div>

                  <Select
                    value={t.status}
                    onValueChange={(v) => {
                      setTableStatus(t.id, v as TableStatus);
                      toast.success(`Table ${t.number} marked ${v}`);
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {STATUSES.map((s) => (
                        <SelectItem key={s} value={s}>
                          {s}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <div className="flex gap-2">
                    {order ? (
                      <Button
                        variant="outline"
                        className="flex-1"
                        onClick={() => navigate({ to: "/billing", search: { order: order.id } })}
                      >
                        View order
                      </Button>
                    ) : null}
                    <Button className="flex-1 gap-2" onClick={() => setNewFor(t.id)}>
                      <Plus className="h-4 w-4" /> New order
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <OrderDialog
        open={!!newFor}
        onOpenChange={(v) => !v && setNewFor(null)}
        {...(newFor ? { defaultTableId: newFor } : {})}
      />
    </AppLayout>
  );
}
