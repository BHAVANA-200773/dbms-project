<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Data layer
- All app data (menu, orders, tables, customers, settings) lives in a React context store at `src/lib/store.tsx` persisted to localStorage, seeded from `src/lib/sample-data.ts` — no backend is connected, so the demo must work offline.
